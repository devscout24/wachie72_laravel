<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Amenity extends Model
{
    protected $fillable = [
        'name',
        'image',
        'property_id',
        'status',
    ];

    public function properties()
    {
        return $this->belongsToMany(Property::class, 'property_amenity', 'amenity_id', 'property_id');
    }
}
